import { describe, expect, it, vi } from 'vitest';
import {
  ErrorCodes,
  ReviewError,
  formatError,
  isReviewError,
  withRetry,
  withTimeout,
} from '../src/utils/error-handler.js';
import {
  RateLimiter,
  DEFAULT_RATE_LIMITS,
} from '../src/utils/rate-limiter.js';

describe('error-handler utilities', () => {
  it('retries a failed operation and returns the successful result', async () => {
    const fn = vi
      .fn<() => Promise<string>>()
      .mockRejectedValueOnce(new Error('temporary failure'))
      .mockResolvedValueOnce('success');

    const randomSpy = vi.spyOn(Math, 'random').mockReturnValue(0);

    await expect(withRetry(fn, 2, 0)).resolves.toBe('success');
    expect(fn).toHaveBeenCalledTimes(2);

    randomSpy.mockRestore();
  });

  it('throws ReviewError after all retries are exhausted', async () => {
    const fn = vi.fn<() => Promise<string>>().mockRejectedValue(new Error('failure'));
    const randomSpy = vi.spyOn(Math, 'random').mockReturnValue(0);

    await expect(withRetry(fn, 2, 0)).rejects.toMatchObject({
      code: ErrorCodes.RETRY_EXHAUSTED,
    });
    expect(fn).toHaveBeenCalledTimes(2);

    randomSpy.mockRestore();
  });

  it('returns the result when the operation finishes before timeout', async () => {
    await expect(withTimeout(async () => 'done', 100)).resolves.toBe('done');
  });

  it('throws AGENT_TIMEOUT when the operation exceeds the timeout', async () => {
    await expect(
      withTimeout(
        () => new Promise<string>((resolve) => setTimeout(() => resolve('late'), 50)),
        5,
        'Test operation timed out'
      )
    ).rejects.toMatchObject({
      code: ErrorCodes.AGENT_TIMEOUT,
      message: 'Test operation timed out',
    });
  });

  it('identifies and formats ReviewError instances', () => {
    const error = new ReviewError('Bad configuration', ErrorCodes.INVALID_CONFIG);

    expect(isReviewError(error)).toBe(true);
    expect(formatError(error)).toBe('[INVALID_CONFIG] Bad configuration');
    expect(formatError(new Error('ordinary error'))).toBe('ordinary error');
  });
});

describe('RateLimiter', () => {
  it('uses the configured defaults', () => {
    expect(DEFAULT_RATE_LIMITS.maxRequestsPerMinute).toBe(50);
    expect(DEFAULT_RATE_LIMITS.maxTokensPerMinute).toBe(100000);
    expect(DEFAULT_RATE_LIMITS.maxConcurrent).toBe(5);
  });

  it('allows a request within configured limits', () => {
    const limiter = new RateLimiter({
      maxRequestsPerMinute: 2,
      maxTokensPerMinute: 1000,
      maxConcurrent: 1,
    });

    expect(limiter.canProceed(500)).toBe(true);
  });

  it('blocks a request when the concurrent limit is reached', async () => {
    const limiter = new RateLimiter({
      maxRequestsPerMinute: 10,
      maxTokensPerMinute: 10000,
      maxConcurrent: 1,
    });

    await limiter.acquire(100);
    expect(limiter.canProceed(100)).toBe(false);

    limiter.release();
    expect(limiter.canProceed(100)).toBe(true);
  });

  it('tracks request and token usage and releases concurrency', async () => {
    const limiter = new RateLimiter({
      maxRequestsPerMinute: 10,
      maxTokensPerMinute: 10000,
      maxConcurrent: 2,
    });

    await limiter.acquire(250);
    const status = limiter.getStatus();

    expect(status.activeRequests).toBe(1);
    expect(status.requestsInWindow).toBe(1);
    expect(status.tokensInWindow).toBe(250);

    limiter.release(300);
    expect(limiter.getStatus().activeRequests).toBe(0);
    expect(limiter.getStatus().tokensInWindow).toBe(300);
  });
});
