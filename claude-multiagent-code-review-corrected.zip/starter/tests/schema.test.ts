import { describe, expect, it } from 'vitest';
import {
  CodeQualityResultSchema,
  TestCoverageResultSchema,
  RefactoringSuggestionSchema,
} from '../src/types/analysis-results.js';
import { ReviewReportSchema } from '../src/types/report-types.js';

describe('Analysis schemas', () => {
  it('accepts a valid code quality result', () => {
    const result = CodeQualityResultSchema.safeParse({
      file: 'src/app.ts',
      issues: [
        {
          line: 12,
          severity: 'high',
          category: 'security',
          description: 'Input is not validated.',
          suggestion: 'Validate the input before using it.',
        },
      ],
      overallScore: 82,
      summary: 'One security issue was found.',
    });

    expect(result.success).toBe(true);
  });

  it('accepts a valid test coverage result', () => {
    const result = TestCoverageResultSchema.safeParse({
      file: 'src/service.ts',
      hasTests: true,
      testFiles: ['tests/service.test.ts'],
      untestedPaths: [
        {
          type: 'edge-case',
          location: 'empty input',
          priority: 'medium',
          reasoning: 'Empty input is not covered.',
          suggestedTest: "it('handles empty input', () => {})",
        },
      ],
      coverageEstimate: 75,
      summary: 'Most paths are covered.',
    });

    expect(result.success).toBe(true);
  });

  it('accepts a valid refactoring suggestion result', () => {
    const result = RefactoringSuggestionSchema.safeParse({
      file: 'src/service.ts',
      suggestions: [
        {
          type: 'extract-function',
          location: 'processRequest',
          impact: 'medium',
          description: 'Extract validation into a helper.',
          before: 'if (!request.id) { throw new Error("missing id"); }',
          after: 'validateRequest(request);',
          benefits: 'Improves readability and reuse.',
        },
      ],
      summary: 'One extraction opportunity was identified.',
    });

    expect(result.success).toBe(true);
  });

  it('accepts a complete review report', () => {
    const result = ReviewReportSchema.safeParse({
      pullRequest: { owner: 'octocat', repo: 'Hello-World', number: 1 },
      fileReviews: [
        {
          file: 'src/app.ts',
          codeQuality: {
            file: 'src/app.ts',
            issues: [],
            overallScore: 100,
            summary: 'Clean.',
          },
          testCoverage: {
            file: 'src/app.ts',
            hasTests: true,
            testFiles: ['tests/app.test.ts'],
            untestedPaths: [],
            coverageEstimate: 100,
            summary: 'Covered.',
          },
          refactorings: {
            file: 'src/app.ts',
            suggestions: [],
            summary: 'No changes needed.',
          },
        },
      ],
      summary: {
        totalFiles: 1,
        overallScore: 100,
        criticalIssues: 0,
        highPriorityTests: 0,
        refactoringOpportunities: 0,
      },
      recommendations: [],
      metadata: {
        analyzedAt: new Date().toISOString(),
        duration: 120,
        agentVersions: {
          'code-quality-analyzer': '1.0.0',
          'test-coverage-analyzer': '1.0.0',
          'refactoring-suggester': '1.0.0',
        },
      },
    });

    expect(result.success).toBe(true);
  });

  it('rejects an invalid severity value', () => {
    const result = CodeQualityResultSchema.safeParse({
      file: 'src/app.ts',
      issues: [
        {
          line: 1,
          severity: 'urgent',
          category: 'security',
          description: 'Invalid severity.',
          suggestion: 'Fix it.',
        },
      ],
      overallScore: 50,
      summary: 'Invalid result.',
    });

    expect(result.success).toBe(false);
  });
});
