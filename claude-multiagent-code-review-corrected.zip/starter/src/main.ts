import * as dotenv from 'dotenv';
import { writeFileSync, mkdirSync } from 'fs';
import { CodeReviewOrchestrator } from './orchestrator.js';
import { ReportGenerator } from './utils/report-generator.js';
import { logger } from './utils/logger.js';

dotenv.config();

async function main() {
  const [owner, repo, prStr] = process.argv.slice(2);

  if (!owner || !repo || !prStr) {
    logger.error('Missing required arguments.');
    console.log('Usage: npm run dev <owner> <repo> <pr-number>');
    process.exit(1);
  }

  const prNumber = parseInt(prStr, 10);

  if (isNaN(prNumber) || prNumber <= 0) {
    logger.error(
      `Invalid PR number provided: "${prStr}". Must be a positive integer.`
    );
    process.exit(1);
  }

  const hasAnthropicKey = !!process.env.ANTHROPIC_API_KEY;
  const hasAwsKeys =
    !!process.env.AWS_ACCESS_KEY_ID &&
    !!process.env.AWS_SECRET_ACCESS_KEY;

  if (hasAwsKeys) {
    if (!process.env.AWS_REGION) {
      logger.warn('AWS authentication keys found, but AWS_REGION is missing.');
    }

    logger.info('🔐 Using AWS Bedrock authentication');
  } else if (hasAnthropicKey) {
    logger.info('🔐 Using Anthropic API authentication');
  } else {
    logger.error('Authentication configuration missing.');

    console.error(
      'Please configure either ANTHROPIC_API_KEY or ' +
      '(AWS_ACCESS_KEY_ID + AWS_SECRET_ACCESS_KEY + AWS_REGION) in your .env file.'
    );

    process.exit(1);
  }

  const model =
    process.env.ANTHROPIC_MODEL || 'claude-3-5-sonnet-20241022';

  logger.info(
    `Starting code review for ${owner}/${repo} PR #${prNumber} using model ${model}...`
  );

  try {
    const orchestrator = new CodeReviewOrchestrator({ model });

    const report = await orchestrator.reviewPullRequest(
      owner,
      repo,
      prNumber
    );

    const reportGenerator = new ReportGenerator();

    const markdownReport =
      reportGenerator.generateMarkdownReport(report);

    const htmlReport =
      reportGenerator.generateHTMLReport(report);

    const jsonReport =
      reportGenerator.generateJSONReport(report);

    // Create reports directory if it doesn't exist
    mkdirSync('./reports', { recursive: true });

    // Save reports to files
    writeFileSync(
      `./reports/${owner}-${repo}-pr-${prNumber}.md`,
      markdownReport
    );

    writeFileSync(
      `./reports/${owner}-${repo}-pr-${prNumber}.html`,
      htmlReport
    );

    writeFileSync(
      `./reports/${owner}-${repo}-pr-${prNumber}.json`,
      jsonReport
    );

    // Also display Markdown report in terminal
    console.log(markdownReport);

    logger.info(
      `Successfully generated all review reports for ${owner}/${repo} PR #${prNumber}`
    );

    logger.info('Reports saved in the ./reports directory.');
  } catch (error) {
    logger.error(
      'An error occurred during PR review processing:',
      error
    );

    process.exit(1);
  }
}

main();